#include "lista.h"
#include "balloc.h"
#include <ctype.h>

void soma();
void multiplicacao();
void divide();
elemento* opera_soma(elemento *grande1, elemento *grande2);
elemento* opera_multiplicacao(elemento *grande1, elemento *grande2);
void godel();